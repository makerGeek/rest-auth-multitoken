from django.apps import AppConfig


class DjangoRestMultitokenConfig(AppConfig):
    name = 'rest_auth_multitoken'
